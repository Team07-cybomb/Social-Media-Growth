// src/components/AffiliatePage.tsx
import React from "react";
import {
  ArrowRight,
  Users,
  DollarSign,
  BarChart3,
  Clock,
  Shield,
  TrendingUp,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { useNavigate } from "react-router-dom";

const AffiliatePage: React.FC = () => {
  const navigate = useNavigate();

  const stats = [
    { number: "30%", label: "Commission Rate", icon: DollarSign },
    { number: "60", label: "Day Cookie Duration", icon: Clock },
    { number: "24h", label: "Payout Processing", icon: TrendingUp },
    { number: "$50", label: "Minimum Payout", icon: Shield },
  ];

  const benefits = [
    {
      icon: DollarSign,
      title: "High Commissions",
      description:
        "Earn up to 30% on every sale you refer with our tiered commission structure.",
    },
    {
      icon: BarChart3,
      title: "Real-time Dashboard",
      description:
        "Track clicks, conversions, and earnings in real-time with our intuitive dashboard.",
    },
    {
      icon: Users,
      title: "Dedicated Support",
      description:
        "Get personalized assistance from our affiliate management team whenever you need it.",
    },
    {
      icon: Shield,
      title: "Reliable Payments",
      description:
        "Receive your earnings reliably every month through PayPal or bank transfer.",
    },
  ];

  const faqs = [
    {
      question: "How do I sign up for the affiliate program?",
      answer:
        "Click the 'Join Now' button and complete our application form. We review all applications within 1-2 business days. Once approved, you'll get immediate access to your affiliate dashboard.",
    },
    {
      question: "How much can I earn as an affiliate?",
      answer:
        "Our standard commission rate is 30% on all sales. We also offer performance bonuses for top affiliates who exceed certain thresholds, with opportunities to earn up to 40% on sales.",
    },
    {
      question: "How do I get paid?",
      answer:
        "We pay commissions via PayPal or bank transfer on the 1st of every month. You can easily track your earnings in the affiliate dashboard.",
    },
    {
      question: "What marketing materials do you provide?",
      answer:
        "We provide banners, links, email templates, social media content, and other resources to help you promote effectively across all channels.",
    },
  ];

  const handleJoinNow = () => {
    navigate("/register");
  };

  const handleContactSupport = () => {
    navigate("/contact");
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-background to-secondary/20">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center justify-center p-2 bg-blue-100 rounded-full mb-6">
            <span className="text-blue-600 font-medium text-sm">
              AFFILIATE PROGRAM
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl mb-6">
            Join Our <span className="text-primary">Affiliate Program</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Earn generous commissions by promoting our services. Our program
            offers competitive rates, timely payments, and all the tools you
            need to succeed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleJoinNow}
              className="rounded-full px-8 py-6 group"
            >
              Join Now
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="rounded-full px-8 py-6"
              onClick={() => {
                const element = document.getElementById("how-it-works");
                element?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card
                  key={index}
                  className="text-center hover:shadow-lg transition-shadow"
                >
                  <CardContent className="p-6">
                    <div className="w-12 h-12 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-primary mb-1">
                      {stat.number}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.label}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section
        id="how-it-works"
        className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20"
      >
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground">
              Start earning commissions in just three simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Connecting line for visual flow */}
            <div className="hidden md:block absolute top-16 left-1/3 right-1/3 h-0.5 bg-primary/20 z-0"></div>

            {[
              {
                step: "1",
                title: "Sign Up",
                description:
                  "Register for our affiliate program through our simple application process. Approval typically takes 1-2 business days.",
              },
              {
                step: "2",
                title: "Promote",
                description:
                  "Use your unique affiliate link and marketing materials to promote our services to your audience.",
              },
              {
                step: "3",
                title: "Earn",
                description:
                  "Earn up to 30% commission on every sale. Track your performance in real-time and get paid monthly.",
              },
            ].map((step, index) => (
              <Card
                key={index}
                className="text-center relative z-10 hover:shadow-lg transition-shadow"
              >
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">Program Benefits</h2>
            <p className="text-lg text-muted-foreground">
              Everything you need to maximize your earnings
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">
                          {benefit.title}
                        </h3>
                        <p className="text-muted-foreground">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Perfect For Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">Perfect For</h2>
            <p className="text-lg text-muted-foreground">
              Whether you're a content creator, marketer, or business owner
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Bloggers",
                description: "Monetize your content and audience",
              },
              {
                title: "YouTubers",
                description: "Earn from product recommendations",
              },
              {
                title: "Influencers",
                description: "Leverage your social media presence",
              },
              { title: "Marketers", description: "Add value for your clients" },
            ].map((item, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-lg transition-shadow"
              >
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-muted-foreground">
              Find answers to common questions about our affiliate program
            </p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-3">{faq.question}</h3>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 to-secondary/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl mb-4">Ready to Start Earning?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join hundreds of affiliates who are already earning commissions with
            our program
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleJoinNow}
              className="rounded-full px-8 py-6 group"
            >
              Join Affiliate Program
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="rounded-full px-8 py-6"
              onClick={handleContactSupport}
            >
              Contact Support
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AffiliatePage;
