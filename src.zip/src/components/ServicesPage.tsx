import { Instagram, Linkedin, Facebook, Twitter, Youtube } from "lucide-react";
import { ServiceCard } from "./ServiceCard";

interface ServicesPageProps {
  onNavigate: (page: string) => void;
}

export function ServicesPage({ onNavigate }: ServicesPageProps) {
  const services = [
    {
      icon: Instagram,
      title: "Instagram Growth",
      description: "Boost your Instagram presence with authentic followers, increased engagement, and strategic content optimization.",
      features: [
        "Organic follower growth strategies",
        "Content creation and curation",
        "Hashtag research and optimization",
        "Story and Reels strategy",
        "Influencer collaboration guidance",
        "Analytics and performance tracking"
      ]
    },
    {
      icon: Linkedin,
      title: "LinkedIn Growth",
      description: "Build your professional network, establish thought leadership, and generate quality B2B leads through strategic LinkedIn growth.",
      features: [
        "Professional network expansion",
        "Content strategy for thought leadership",
        "Lead generation optimization",
        "Personal branding development",
        "Connection building strategies",
        "LinkedIn article writing"
      ]
    },
    {
      icon: Facebook,
      title: "Facebook Growth",
      description: "Expand your Facebook reach with targeted audience growth, engaging content, and effective community building strategies.",
      features: [
        "Targeted audience development",
        "Facebook page optimization",
        "Community management",
        "Facebook ads strategy",
        "Event promotion tactics",
        "Cross-platform integration"
      ]
    },
    {
      icon: Twitter,
      title: "X (Twitter) Growth",
      description: "Amplify your voice on X with strategic tweeting, trending topic participation, and authentic follower acquisition.",
      features: [
        "Tweet strategy and timing",
        "Trending hashtag participation",
        "Thread creation for engagement",
        "Twitter Spaces strategy",
        "Influencer engagement tactics",
        "Real-time marketing opportunities"
      ]
    },
    {
      icon: Youtube,
      title: "YouTube Growth",
      description: "Grow your YouTube channel with optimized content, improved discoverability, and increased subscriber engagement.",
      features: [
        "Video SEO optimization",
        "Thumbnail design strategy",
        "Content planning and scheduling",
        "Audience retention techniques",
        "YouTube Shorts strategy",
        "Monetization guidance"
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Header Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-background to-secondary/20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl mb-6">
            Our <span className="text-primary">Services</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Comprehensive social media growth solutions designed to elevate your brand 
            across all major platforms. Each service is tailored to your specific goals 
            and industry requirements.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                onGetStarted={() => onNavigate("contact")}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">
              Our Growth Process
            </h2>
            <p className="text-lg text-muted-foreground">
              A proven 4-step methodology that delivers consistent results
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Analysis",
                description: "We analyze your current social media presence and identify growth opportunities."
              },
              {
                step: "02", 
                title: "Strategy",
                description: "Create a customized growth strategy aligned with your business goals and target audience."
              },
              {
                step: "03",
                title: "Implementation",
                description: "Execute the strategy with consistent content creation and engagement tactics."
              },
              {
                step: "04",
                title: "Optimization",
                description: "Monitor performance and continuously optimize for better results and ROI."
              }
            ].map((process, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-primary text-primary-foreground rounded-full flex items-center justify-center">
                  <span className="text-lg">{process.step}</span>
                </div>
                <h3 className="text-lg mb-2">{process.title}</h3>
                <p className="text-muted-foreground text-sm">{process.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl mb-4">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-8">
            {[
              {
                question: "How long does it take to see results?",
                answer: "Most clients start seeing noticeable growth within 30-60 days, with significant results typically visible after 3-6 months of consistent strategy implementation."
              },
              {
                question: "Do you guarantee follower growth?",
                answer: "While we cannot guarantee specific numbers due to platform algorithm changes, our proven strategies have delivered consistent growth for 95% of our clients."
              },
              {
                question: "Can I choose multiple platforms?",
                answer: "Absolutely! Many clients benefit from multi-platform strategies. We offer bundled packages that provide better value for multiple platform growth."
              },
              {
                question: "Do you create content for us?",
                answer: "Yes, our services include content strategy, creation, and curation tailored to your brand voice and audience preferences."
              }
            ].map((faq, index) => (
              <div key={index} className="border-b border-border pb-6">
                <h3 className="text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}